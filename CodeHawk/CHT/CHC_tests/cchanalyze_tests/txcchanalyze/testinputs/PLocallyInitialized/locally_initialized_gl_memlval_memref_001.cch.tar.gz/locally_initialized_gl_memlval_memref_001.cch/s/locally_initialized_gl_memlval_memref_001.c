
typedef struct _mystruct {
  int fld1;
  int fld2;
} mystruct;


void gl_memlval_memref_001(int *q) {

  mystruct s;
  mystruct *p = &s;

  int c = p->fld1;

  return;
}
