# 0 "locally_initialized_gl_memlval_memref_001.c"
# 1 "/home/henny/CCode/testfiles/test_initialized//"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "locally_initialized_gl_memlval_memref_001.c"

typedef struct _mystruct {
  int fld1;
  int fld2;
} mystruct;


void gl_memlval_memref_001(int *q) {

  mystruct s;
  mystruct *p = &s;

  int c = p->fld1;

  return;
}
