
typedef struct _mystruct {
  int fld1;
  int fld2;
  int fld3;
} mystruct;


void rl_memlval_002(mystruct *p) {

  mystruct *q = p;

  int c = q->fld1;

  return;
}
