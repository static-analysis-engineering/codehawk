# 0 "locally_initialized_gl_inv_001.c"
# 1 "/home/henny/CCode/testfiles/test1//"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "locally_initialized_gl_inv_001.c"

void gl_inv_001(int *p) {

  *p = 5;
  int c = *p;

  return;
}
