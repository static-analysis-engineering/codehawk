
void gl_inv_001(int *p) {

  *p = 5;
  int c = *p;

  return;
}
