# 0 "locally_initialized_rl_xpr_002.c"
# 1 "/home/henny/CCode/testfiles/test1//"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "locally_initialized_rl_xpr_002.c"

void rl_xpr_002(int *p, int k) {

  int c;

  if (k > 5) {
    c = *p;
  }

  return;
}
