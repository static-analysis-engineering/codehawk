
void rl_xpr_002(int *p, int k) {

  int c;
  
  if (k > 5) {
    c = *p;
  }

  return;
}
