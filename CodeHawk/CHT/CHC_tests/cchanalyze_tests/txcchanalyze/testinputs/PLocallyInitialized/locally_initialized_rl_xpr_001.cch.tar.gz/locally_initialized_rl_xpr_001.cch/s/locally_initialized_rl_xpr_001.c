
void rl_xpr_001(int *p) {

  int c = *p;

  return;
}
