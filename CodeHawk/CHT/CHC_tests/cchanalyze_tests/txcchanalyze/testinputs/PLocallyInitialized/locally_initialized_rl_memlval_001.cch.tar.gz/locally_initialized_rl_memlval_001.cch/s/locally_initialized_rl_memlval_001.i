# 0 "locally_initialized_rl_memlval_001.c"
# 1 "/home/henny/CCode/testfiles/test1//"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "locally_initialized_rl_memlval_001.c"

typedef struct _mystruct {
  int fld1;
  int fld2;
  int fld3;
} mystruct;


void rl_memlval_001(mystruct *p) {

  int c = p->fld1;

  return;
}
