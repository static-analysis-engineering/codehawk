
typedef struct _mystruct {
  int fld1;
  int fld2;
  int fld3;
} mystruct;


void rl_memlval_001(mystruct *p) {

  int c = p->fld1;

  return;
}
