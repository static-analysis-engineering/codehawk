/* Initialized proven for a dereferenced value. */

int gl_inv_xpr_002(void) {

  int i = 5;

  int *p = &i;

  i = 8;

  return *p;
}
