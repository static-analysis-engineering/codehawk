/* Initialized proven for initialization through aliased variable. */

int gl_inv_xpr_003(void) {

  int i;

  int *p = &i;

  *p = 8;

  return i;
}
