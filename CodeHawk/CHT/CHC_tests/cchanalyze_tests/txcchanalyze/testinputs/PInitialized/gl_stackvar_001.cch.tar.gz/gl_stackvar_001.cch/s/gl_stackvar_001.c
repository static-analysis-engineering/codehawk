/* Initialized proven by proving assignment to aliased variable. */

int gl_stackvar_001(int k) {

  int i;
  int *p = &i;

  if (k > 5) {
    i = 5;
  } else {
    i = k;
  }

  return *p;
}
