/* Initialized proven for a dereferenced value. */

int gl_inv_xpr_001(void) {

  int i = 5;

  int *p = &i;

  return *p;
}
