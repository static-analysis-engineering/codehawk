/* Initialized proven by proving the value is bounded. */

int gl_inv_bounded_xpr_001(int k) {

  int i;
  int *p = &i;

  if (k > 5) {
    i = 5;
  } else {
    i = 3;
  }

  return *p;
}
