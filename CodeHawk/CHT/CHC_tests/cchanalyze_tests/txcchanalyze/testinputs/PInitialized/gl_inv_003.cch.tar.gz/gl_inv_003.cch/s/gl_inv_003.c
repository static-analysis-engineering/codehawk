/* Initialized proven by symbolic invariant over multiple paths. */


int gl_inv_003(int k) {

  int i;

  if (k > 0) {
    i = 5;
  } else {
    i = 3;
  }

  return i;
}
