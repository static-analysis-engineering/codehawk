/* Initialized field proven by symbolic invariant. */

typedef struct mystruct_s {
  int fld1;
  int fld2;
} mystruct;


int gl_inv_002(void) {

  mystruct s = {.fld1 = 5, .fld2 = 3 };

  return s.fld1;
}
