/* Initialized proven by symbolic invariant. */

int gl_inv_001(void) {

  int i = 5;

  return i;
}
