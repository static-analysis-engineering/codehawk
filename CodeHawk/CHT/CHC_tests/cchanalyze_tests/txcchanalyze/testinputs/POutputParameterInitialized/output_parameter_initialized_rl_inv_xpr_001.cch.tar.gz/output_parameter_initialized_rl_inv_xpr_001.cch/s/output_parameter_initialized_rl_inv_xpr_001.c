
void rl_inv_xpr_001(int *p) {

  int c = *p;

  return;
}
