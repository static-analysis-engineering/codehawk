# 0 "output_parameter_initialized_rl_inv_xpr_001.c"
# 1 "/home/henny/CCode/testfiles/test1//"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "output_parameter_initialized_rl_inv_xpr_001.c"

void rl_inv_xpr_001(int *p) {

  int c = *p;

  return;
}
