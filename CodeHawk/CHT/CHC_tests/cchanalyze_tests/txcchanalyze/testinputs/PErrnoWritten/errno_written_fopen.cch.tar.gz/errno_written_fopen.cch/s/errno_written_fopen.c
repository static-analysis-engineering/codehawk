#include <stdio.h>
#include <errno.h>

int main_fopen(int argc)
{
    FILE *f = fopen("asdf", "r");

    if (f == NULL) {
  	printf("ERRNO: %d\n", errno);
	return 1;
    }

    return 0;
}
