#include <stdio.h>
#include <errno.h>

int main(int argc)
{
    FILE *f = fopen("asdf", "r");

    if (f) {
	if (fseek(f,0,0) != 0) {
   	    printf("ERRNO: %d\n", errno);
	    return;
	}
    }

    return 0;
}
