#include <stdio.h>
#include <errno.h>

int foo(FILE *f)
{
    if (fclose(f) != 0)
    {
        printf("ERRNO: %d\n", errno);
        return 1;
    }

    return 0;
}
