#include <stdio.h>
#include <errno.h>

int main_fclose(FILE *f)
{
    if (fclose(f) != 0)
    {
        printf("ERRNO: %d\n", errno);
        return 1;
    }

    return 0;
}
