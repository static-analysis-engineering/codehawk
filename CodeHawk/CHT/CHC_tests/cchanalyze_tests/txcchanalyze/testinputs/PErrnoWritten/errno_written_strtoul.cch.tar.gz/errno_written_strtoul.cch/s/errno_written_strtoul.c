#include <stdlib.h>
#include <errno.h>
int main_strtoul() {
	errno = 0;
	unsigned long x = strtoul("0", NULL, 10);
	if (errno != 0) { return 1; } 
	return 0;
}
