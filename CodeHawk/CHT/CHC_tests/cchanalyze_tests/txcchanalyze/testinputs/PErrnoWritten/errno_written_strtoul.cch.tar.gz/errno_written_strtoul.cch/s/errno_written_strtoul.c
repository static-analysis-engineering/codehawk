#include <stdlib.h>
#include <errno.h>
int main() {
	errno = 0;
	unsigned long x = strtol("0", NULL, 10);
	if (errno != 0) { return 1; } 
	return 0;
}
