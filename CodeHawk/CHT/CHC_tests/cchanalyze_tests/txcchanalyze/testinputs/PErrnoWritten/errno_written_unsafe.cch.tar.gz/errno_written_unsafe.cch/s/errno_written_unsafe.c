#include <errno.h>
typedef struct { int a; int b; } res_t; 
extern res_t foo();

int main_unsafe() {
	errno = 0;
	res_t r = foo();

	if (errno != 0) 
		return 1;

	return 0;
}
